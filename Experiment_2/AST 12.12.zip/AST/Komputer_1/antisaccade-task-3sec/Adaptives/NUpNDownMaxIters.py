from .AbstractAdaptive import AbstractAdaptive


class NUpNDownMaxIters(AbstractAdaptive):
    pass