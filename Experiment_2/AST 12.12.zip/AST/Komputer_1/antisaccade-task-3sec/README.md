# antisaccade-task
Experimental procedure for an antisaccadic task written in Psychopy and Python 3.8




#Credit
Written by [Bartek Kroczek](www.bartekkroczek.github.io)  
  
<a rel="license" href="http://creativecommons.org/licenses/by-sa/2.5/ca/"><img alt="Creative Commons Licence" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/2.5/ca/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/2.5/ca/">Creative Commons Attribution-ShareAlike 2.5 Canada License</a>.