from .AbstractAdaptive import AbstractAdaptive


class MaxIters(AbstractAdaptive):
    pass
